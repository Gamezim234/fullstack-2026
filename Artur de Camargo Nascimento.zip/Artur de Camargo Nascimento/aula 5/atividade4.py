cont = 1 
maior = 0 
while cont <= 6 : 
    numero = int(input("digite um numero"))
    if numero > maior : 
         maior = numero 
    else:
         maior = maior

    cont = cont + 1 
print("O maior numero é ", maior)

    