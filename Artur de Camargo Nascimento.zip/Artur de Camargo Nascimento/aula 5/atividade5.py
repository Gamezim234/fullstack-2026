num = -1
while num < 0 or num > 10:
    num = int(input("Digite um numero: "))
    if num < 0 or num > 10:
        print("numero invalido")
print("Numero valido")
