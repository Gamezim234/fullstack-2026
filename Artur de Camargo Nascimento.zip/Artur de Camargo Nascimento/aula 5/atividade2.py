num = 1
while True:
     if num <= 50:
        print(num)
        num = num + 1
     else:
         break
num = 52
while True:
    if num <= 100 :
        print(num)
        num = num + 2
    else:
        break
       
   