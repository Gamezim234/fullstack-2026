total = 0          
contador = 1       
while contador <= 10:
    valor = float(input(f"Digite o {contador}º número: "))
    total += valor
    contador += 1

print(f"A soma dos 10 números é: {total}")