# pegando o numero com o usuario
num1 = int(input("Digite um numero"))

#verificando se é ou não par
while True :
    if  num1 % 2 ==0 :
        print(num1)
        num1 = num1 - 2
    else:
        num1 = num1 - 1
        print(num1)
        num1 = num1 - 2
    if num1 == 0 :
        break