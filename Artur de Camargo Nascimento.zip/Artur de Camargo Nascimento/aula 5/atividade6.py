qtd_num = 0
soma = 0
while True:
    num = float(input("Digite um numero: "))
    qtd_num = qtd_num + 1
    soma = soma + num 
    media = soma / qtd_num
    if num == 0 :
        print("a quantidade de numero foi: ", qtd_num )
        print("a soma dos numeros é: ", soma)
        print(" a média aritimetica é :", media)
        break