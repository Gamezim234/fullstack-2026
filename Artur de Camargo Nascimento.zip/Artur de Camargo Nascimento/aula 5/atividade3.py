num = int(input("digite um numero: "))
mut = 1
while mut < 10:
    print(num, "mutplicado por ", mut, " é = ", num * mut)
    mut = mut + 1
10
