import sqlite3
usuario = input("Digite o nome de usuário:")
senha = input("Digite a senha:")
# Conectar ao banco de dados (ou criar se não existir)
conexao = sqlite3.connect('exemplo.db')
# Criar um cursor para executar comandos SQL
cursor =conexao.cursor()
# Criar uma tabela chamada "usuarios"
cursor.execute("INSERT INTO usuarios (user_id, Password) VALUES (?, ?)", (usuario, senha))

conexao.commit()

