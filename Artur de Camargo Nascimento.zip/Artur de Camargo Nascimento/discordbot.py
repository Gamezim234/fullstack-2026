import discord
from discord.ext import commands

# Substitua 'YOUR_BOT_TOKEN' pelo token do seu bot do Discord
TOKEN = 'c01596c5e18bed1dbd552c3e75fe2679e3585d2be3cd68e0322c9d3df8df0c2d'

bot = commands.Bot(command_prefix='!')

@bot.event
async def on_ready():
    print(f'Bot conectado como {bot.user}')

@bot.command()
async def ping(ctx):
    await ctx.send('Pong!')

bot.run(TOKEN)
