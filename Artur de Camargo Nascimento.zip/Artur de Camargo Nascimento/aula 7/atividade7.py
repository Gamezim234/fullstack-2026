# Escreva aqui seu código para verificar se um número pertence à sequência de Fibonacci

n = int(input("Digite um número: "))
a = 0
b = 1
for i in range(n):
   novo = a + b
   a = b
   b = novo 
   if n == a or n == b:
        print(f"O número {n} pertence à sequência de Fibonacci.")
        break      
   elif n < a and n < b:     
        print(f"O número {n} não pertence à sequência de Fibonacci.")
        break
        