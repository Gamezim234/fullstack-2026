quantidade = int(input("digite a quantidade de numeros: "))
primos = 0
for i in range(quantidade):
    numbers = int(input(f"Digite o {i} numero: "))
    divisores = 0
    for j in range(1, numbers + 1):
        if numbers % j == 0:
            divisores += 1
    if divisores == 2:
     primos += 1
print(f"quantidade de numeros primos é {primos} em um total de {quantidade}")
