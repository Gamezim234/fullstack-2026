L = int(input("DIGITE UM NUMERO INTEIRO PARA A LATERAL: "))
C = int(input("DIGITE UM NUMERO INTEIRO PARA O COMPRIMENTO"))
for i in range(1, L + 1):
    for j in range(1, C + 1):
        if i == 1 or i == L or j == 1 or j == C:
            print("*", end=" ")
        else:
            print(" ", end=" ")
    print()



    