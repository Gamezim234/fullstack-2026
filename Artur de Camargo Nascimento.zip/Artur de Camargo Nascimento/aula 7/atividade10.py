def mutiplo(x, y):
    if x % y == 0:
        return True
    
    else: 
        return False

num1 = int(input("Digite o primeiro número: "))
num2 = int(input("Digite o segundo número: "))
mutiplo(num1, num2)
    