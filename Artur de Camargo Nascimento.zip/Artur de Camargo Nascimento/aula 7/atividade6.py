number = int(input("Digite um número Natural: "))
digitos = 0
while number > 0:
    number = number // 10 
    digitos = digitos + 1
    if number == 0:
        print(f"O número tem {digitos} dígitos.")
    