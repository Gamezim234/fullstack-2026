n = int(input("Digite o tamanho do tabuleiro: "))

for i in range(n):
    for j in range(n):
        if i % 2 == 0:           # linhas 0,2,4...
            if j % 2 == 0:
                print("$", end=" ")
            else:
                print("&", end=" ")
        else:                    # linhas 1,3,5...
            if j % 2 == 0:
                print("%", end=" ")
            else:
                print("#", end=" ")
    print()