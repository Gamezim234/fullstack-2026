def area_Triangulo( B , H):
    area = (B * H) / 2
    print(f"A área do triângulo é {area}")

B = float(input("Digite a base do triângulo: "))
H = float(input("Digite a altura do triângulo: "))
area_Triangulo(B, H)
