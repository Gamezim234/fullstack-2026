n= int(input("Digite o tamanho:"))
for i in range(n):
    for j in range(n):
        if  j <= i:
            print("$", end=" ")
        else:
            print("@10" \
            "", end=" ")
    print()