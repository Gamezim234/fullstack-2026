def media(num1, num2):
    resultado = (num1 + num2) / 2
    print(f"a média dos numeros é {resultado}")

num1 = float(input("digite o primeiro numero"))
num2 = float(input("digite o segundo numero"))
media(num1, num2)