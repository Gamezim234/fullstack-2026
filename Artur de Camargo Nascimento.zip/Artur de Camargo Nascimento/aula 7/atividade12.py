def raiz_quadrada(n1, n2, n3):
    resultado = (n1**0.5) + (n2**0.5) + (n3**0.5) + (n1+n2)/2 + (n2+n3)/2 + (n1+n3)/2
    print(resultado)

n1 = float(input("Digite n1: "))
n2 = float(input("Digite n2: "))
n3 = float(input("Digite n3: "))
raiz_quadrada(n1, n2, n3)