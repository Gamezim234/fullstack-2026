def maximo(x, y):
    if x > y:
        print("O número maior é:", x)
    else:
        print("O número maior é:", y)

num1 = int(input("Digite o primeiro número: "))
num2 = int(input("Digite o segundo número: "))
maximo(num1, num2)