import pynput
import time
from pynput import keyboard

def on_press(key):
    try:
        print('Tecla {} pressionada.'.format(key.char))
    except AttributeError:
        print('Tecla especial {} pressionada.'.format(key))
    if key == keyboard.Key.esc:
        print('Tecla "Esc" pressionada. Encerrando o programa.')
        return False
    
listener = keyboard.Listener(on_press=on_press)
listener.start()
listener.join()