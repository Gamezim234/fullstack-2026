import sqlite3

def main():
   while True: 
        conexao = sqlite3.connect("usuarios.db")
        cursor = conexao.cursor()
        conexao.execute("CREATE TABLE IF NOT EXISTS usuarios (username TEXT, password TEXT)")
        criarOUlogar = input("Você deseja se registrar ou fazer login? (Digite 'register' para registrar ou 'login' para fazer login): ")
        online = False
    
        if criarOUlogar == "register":
            username = input("Digite um nome de usuário: ")
            password = input("Digite uma senha: ")
            cursor.execute("INSERT INTO usuarios (username, password) VALUES (?, ?)", (username, password))
            conexao.commit()
            print("Registro bem-sucedido!")
        elif criarOUlogar == "login":
            username = input("Digite seu nome de usuário: ")
            password = input("Digite sua senha: ")
            cursor.execute("SELECT * FROM usuarios WHERE username = ? AND password = ?", (username, password))
            resultado = cursor.fetchone()
            if resultado:
                print("Login bem-sucedido!")
    
            else:
                print("Nome de usuário ou senha incorretos.")
         
        else:
            print("Opção inválida. Por favor, escolha 'register' ou 'login'.")
        if input("Deseja continuar? (s/n)").lower() != "s":
            break
        
main()