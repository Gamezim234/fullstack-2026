import sqlite3
conexao = sqlite3.connect("produtos.db")
cursor = conexao.cursor()
produto_id = input("Digite o nome do produto:")
quantidade = int(input("Digite a quantidade do produto:"))
cursor.execute("CREATE TABLE IF NOT EXISTS produtos (produto_id TEXT, quantidade INTEGER)")
cursor.execute("INSERT INTO produtos (produto_id, quantidade)  VALUES (?, ?)", (produto_id, quantidade))
conexao.commit()
