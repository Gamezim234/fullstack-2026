while True:
    preco = float(input("Digite o preço do produto: "))
    CD = int(input("Digite o código de origem: "))
    if CD == 1: 
        print("o valor é: ", preco, " e o produto é do sul")
    elif CD == 2:
        print("o valor é: ", preco, " e o produto é do Norte")
    elif CD == 3:   
        print("o valor é: ", preco, " e o produto é do Leste")
    elif CD == 4:
        print("o valor é: ", preco, " e o produto é do Oeste")
    elif CD == 5 or CD == 6:
        print("o valor é: ", preco, " e o produto é do Nordeste")
    elif CD == 7 or CD == 8 or CD == 9:
        print("o valor é:", preco, " e o produto é do Sudeste")
    elif CD >= 10 and CD <= 20:
        print("o valor é: ", preco, " e o produto é do Centro-Oeste")
    elif CD >= 25 and CD <= 30:
        print("o valor é: ", preco, " e o produto é do Noroeste")
    else: 
        print("O valor é: ", preco, " e o produto é importado") 
    if input("Deseja continuar? (s/n): ").lower() != 's':
        break