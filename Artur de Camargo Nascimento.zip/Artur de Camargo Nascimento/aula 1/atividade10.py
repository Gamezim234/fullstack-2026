# Escreva um algoritmo que leia o código de um determinado
# produto e mostre a sua classificação. Utilize a seguinte
# tabela como referência:
# Código Classificação
# 1 Alimento não perecível
# 2, 3 ou 4 Alimento perecível
# 5 ou 6 Vestuário
# 7 Higiene pessoal
# 8 até 15 Limpeza e utensílios domésticos
# Qualquer outro código Inválido
while True:
    codigo_produto = int(input("Digite o código do protudo: "))
    if codigo_produto == 1:
        print("Alimento não perecível")
    elif codigo_produto in [2, 3, 4]:
        print("Alimento perecível")
    elif codigo_produto in [5, 6]:
        print("Vestuário")
    elif codigo_produto == 7:
        print("Higiene pessoal")
    elif codigo_produto >= 8 and codigo_produto <= 15:
        print("limpeza e untensílios domésticos")
    else:
        print("código inválido")
    if input("Deseja continuar? (s/n)").lower() != "s":
        break