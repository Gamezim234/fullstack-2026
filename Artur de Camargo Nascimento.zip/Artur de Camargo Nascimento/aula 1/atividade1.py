# Atividade 1: Escreva um programa que solicite ao usuário dois números e imprima o menor deles.
num1 = float(input("Digite o primeiro número: "))
num2 = float(input("Digite o segundo número: "))
# Comparar os números e imprimir o menor
if num1 < num2:
    print( num1, " é menor que ", num2)


