while True:
    num1 = float(input("Digite o primeiro número: "))
    num2 = float(input("Digite o segundo número: "))
    num3 = float(input("Digite o terceiro número: "))
    decrescente = False
    if num1 > num2 and num2 > num3:
        print("os números em ordem decrescente são: ", num1, num2, num3)
    elif num1 > num3 and num3 > num2:
        print("os números em ordem decrescente são: ", num1, num3, num2)
    elif num2 > num1 and num1 > num3:
        print("os números em ordem decrescente são: ", num2, num1, num3)
    elif num2 > num3 and num3 > num1:
        print("os números em ordem decrescente são: ", num2, num3, num1)
    elif num3 > num1 and num1 > num2:
        print("os números em ordem decrescente são: ", num3, num1, num2)
    elif num3 > num2 and num2 > num1:
        print("os números em ordem decrescente são: ", num3, num2, num1)
    else:
        print("os números são iguais")
    if input("Deseja continuar? (s/n): ").lower() != "s":
        break


   