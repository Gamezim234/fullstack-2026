while True:
    altura = float(input("Digite a altura em metros: "))
    sexo = input("Digite o seu sexo (M/F): ")
    peso_idealM = (72.7 * altura) - 58
    peso_idealF = (62.1 * altura) - 44.7
    if sexo == "M" or sexo == "m":
        print("O peso ideal para homens é: ", peso_idealM, "kg")
    elif sexo == "F" or sexo == "f":
        print("O peso ideal para mulheres é: ", peso_idealF, "kg")
    if input("Deseja continuar? (s/n): ").lower() != "s":
        break