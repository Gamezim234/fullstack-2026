import sqlite3

conexao = sqlite3.connect('historico.db')
cursor = conexao.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS historico (lado_a INTEGER, lado_b INTEGER, lado_c INTEGER, tipo_triangulo TEXT)")
equilatero = False
isosceles = False
nao_triangulo = False
while True:
    a = int(input("Lado a: "))
    b = int(input("Lado b: "))
    c = int(input("Lado c: "))
    if a < b + c and b < a + c and c < a + b:
        if a == b and b == c:
            print("Triangulo equilatero")
            equilatero = True
        else:
            if a == b or b == c or a == c:
                print("Triangulo isosceles")
                isosceles = True
            else:
                print("Triangulo escaleno")
                escaleno = True
    else:
        print("Não é um triangulo")
        nao_triangulo = True

    if equilatero == True:
        tipo_triangulo = "Equilatero"
        equilatero = False
    elif isosceles == True:
        tipo_triangulo = "Isosceles"
        isosceles = False
    elif escaleno == True:
        tipo_triangulo = "Escaleno"
        escaleno = False
    else:
        tipo_triangulo = "Não é um triangulo"
        nao_triangulo = False
    cursor.execute("INSERT INTO historico (lado_a, lado_b, lado_c, tipo_triangulo) VALUES (?, ?, ?, ?)", (a, b, c, tipo_triangulo))
    conexao.commit()
    if input("Deseja continuar? (s/n): ").lower() != 's':
        break 

