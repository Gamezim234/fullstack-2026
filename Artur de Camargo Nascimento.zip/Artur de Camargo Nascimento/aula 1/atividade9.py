# Atividade 9 - Verificar se o usuário é eleitor e pode tirar a carteira de habilitação
while True:
    # pega os dados do usuário
    Ano_nascimento = int(input("Digite o ano de nascimento: "))
    ano_atual = int(input("Digite o ano atual: "))
    idade = ano_atual - Ano_nascimento
    eleitor = False
    Carteira_de_habilitacao = False
    #verifica se o usuário é eleitor e se pode tirar a carteira de habilitação
    if idade < 16:
        eleitor = False
    elif idade >= 16 and idade < 18:
        eleitor = True
        Carteira_de_habilitacao = False
    else:
        eleitor = True
        Carteira_de_habilitacao = True
    #imprime o resultado com base nas condições verificadas
    if eleitor == True and Carteira_de_habilitacao == True:
        print("Você é eleitor e pode tirar a carteira de habilitação.")
    elif eleitor == True and Carteira_de_habilitacao == False:
        print("Você é eleitor, mas não pode tirar a carteira de habilitação.")
    else:
        print("Você não é eleitor e não pode tirar a carteira de habilitação.")
    #pergunta se o usuário deseja continuar ou não
    if input("Deseja continuar? (s/n): ").lower() != "s":
        break
   