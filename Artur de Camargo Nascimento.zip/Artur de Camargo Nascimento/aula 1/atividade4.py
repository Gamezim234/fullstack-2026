Salario = float(input("Digite o salário do funcionário: "))
if Salario >= 1250 :
    print("O funcionário tem direito a um aumento de 10%.")
    print("O novo salário do funcionário é: R$", Salario * 1.10)
else:
    print("O funcionário tem direito a um aumento de 15%.")
    print("O novo salário do funcionário é: R$", Salario * 1.15)